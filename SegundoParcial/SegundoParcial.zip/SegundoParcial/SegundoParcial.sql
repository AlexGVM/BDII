/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     10/29/2020 8:31:27 PM                        */
/*==============================================================*/

if exists (select 1
            from  sysobjects
           where  id = object_id('CLIENTE')
            and   type = 'U')
   drop table CLIENTE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('EVENTOS')
            and   type = 'U')
   drop table EVENTOS
go

if exists (select 1
            from  sysobjects
           where  id = object_id('TELEFONO')
            and   type = 'U')
   drop table TELEFONO
go

if exists (select 1
            from  sysobjects
           where  id = object_id('TIPOEVENTO')
            and   type = 'U')
   drop table TIPOEVENTO
go

/*==============================================================*/
/* Table: CLIENTE                                               */
/*==============================================================*/
create table CLIENTE (
   IDCLIENTE            int                  identity(1,1) not null,
   NOMBRE               nvarchar(50)         null,
   APELLIDO             nvarchar(50)         null,
   DPI                  nvarchar(50)         null,
   constraint PK_CLIENTE primary key (IDCLIENTE)
)
go

/*==============================================================*/
/* Table: EVENTOS                                               */
/*==============================================================*/
create table EVENTOS (
   IDEVENTO             int                 identity(1,1) not null,
   IDTIPOEVENTO         int                  null,
   TELEFONO             nvarchar(8)          null,
   FECHA                date                 null,
   HORA                 time                 null,
   TELEFONOORIGEN       nvarchar(8)          null,
   DURACION             decimal              null,
   ESTADO               int                  null,
   constraint PK_EVENTOS primary key (IDEVENTO)
)
go

/*==============================================================*/
/* Table: TELEFONO                                              */
/*==============================================================*/
create table TELEFONO (
   IDCLIENTE            int                  null,
   TELEFONO             nvarchar(8)          not null,
   constraint PK_TELEFONO primary key (TELEFONO)
)
go

/*==============================================================*/
/* Table: TIPOEVENTO                                            */
/*==============================================================*/
create table TIPOEVENTO (
   IDTIPOEVENTO         int                  identity(1,1) not null,
   TIPO                 nvarchar(50)         null,
   constraint PK_TIPOEVENTO primary key (IDTIPOEVENTO)
)
go

alter table EVENTOS
   add constraint FK_EVENTOS_REFERENCE_TIPOEVEN foreign key (IDTIPOEVENTO)
      references TIPOEVENTO (IDTIPOEVENTO)
go

alter table EVENTOS
   add constraint FK_EVENTOS_REFERENCE_TELEFONO foreign key (TELEFONO)
      references TELEFONO (TELEFONO)
go

alter table TELEFONO
   add constraint FK_TELEFONO_REFERENCE_CLIENTE foreign key (IDCLIENTE)
      references CLIENTE (IDCLIENTE)
go

