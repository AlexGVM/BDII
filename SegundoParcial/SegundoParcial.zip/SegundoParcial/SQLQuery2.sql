create or alter trigger ti_telefonos on Eventos
after insert
as

	declare @tipo int
	declare @numero nvarchar(8)
	declare @destino nvarchar(8) 

	select @destino = TELEFONOORIGEN from inserted
	select @tipo = IDTIPOEVENTO from inserted
	select @numero = TELEFONO from inserted
	
	set transaction isolation level read committed; ---se utiliza m�s en las transacciones
	begin transaction

	if ((@numero <> @destino) and (@tipo = 1 or @tipo = 2))
	Begin
		print'Se agrego con exito'
		commit;
	End
	Else
	Begin
		print'No es posible agregar un numero igual al numero del evento'
		ROLLBACK;
	End

CREATE TABLE #EventoTemporal ( IDEVENTO int identity(1,1) not null,
   IDTIPOEVENTO         int                  null,
   TELEFONO             nvarchar(8)          null,
   FECHA                date                 null,
   HORA                 time                 null,
   TELEFONOORIGEN       nvarchar(8)          null,
   DURACION             decimal              null,
   ESTADO               int                  null,
   constraint PK_EVENTOS primary key (IDEVENTO) )

select *
from #EventoTemporal


create or alter proc usp_archivo as

begin

	BULK INSERT #EventoTemporal
	from 'C:\Users\alexg\Desktop\Evento.txt'
	with 
	(
	
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'
	
	)


	declare @fecha date, @hora time, @telefono nvarchar(8), @IDTIPOEVENTO int, @IDEVENTO  int, @TELEFONOORIGEN nvarchar(8), @DURACION decimal, @ESTADO int, @cont int
	set @cont = 1
	Declare InsertarDatos cursor for
	select IDEVENTO,IDTIPOEVENTO,TELEFONO, FECHA, HORA , TELEFONOORIGEN ,  DURACION,  ESTADO 
    from #EventoTemporal
               
    OPEN InsertarDatos            
     
	FETCH NEXT FROM InsertarDatos into @IDEVENTO, @IDTIPOEVENTO, @telefono, @fecha, @hora, @TELEFONOORIGEN, @DURACION, @ESTADO
	while(@@FETCH_STATUS = 0)
	BEGIN
	set transaction isolation level read committed;	
	begin tran
	update EVENTOS
	set  @IDEVENTO = IDEVENTO, IDTIPOEVENTO = @IDTIPOEVENTO,TELEFONO = @telefono, FECHA = @fecha, HORA = @hora, 
	TELEFONOORIGEN = @TELEFONOORIGEN, DURACION = @DURACION ,  ESTADO  =  @ESTADO
	where IDEVENTO = @cont
	set @cont = @cont + 1;
	if(@cont != 50)
	begin
	print 'Se mira la siguiente linea'
	FETCH NEXT FROM InsertarDatos into @IDEVENTO, @IDTIPOEVENTO, @telefono, @fecha, @hora, @TELEFONOORIGEN, @DURACION, @ESTADO
	end
	else
	begin
		print'Se guarda correctamente'
		COMMIT;
	end
	
	END


end
exec usp_archivo


